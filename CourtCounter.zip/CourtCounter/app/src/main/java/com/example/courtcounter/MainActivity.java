package com.example.courtcounter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    int scoreTeamA = 0;
    int scoreTeamB = 0;
    //Button click of team A +3 points ( it calls the method display score for team A)
    public void TeamA_3points(View view){
        scoreTeamA+=3;
        displayForTeamA(scoreTeamA);
    }
    // +2 points button click for team A, it also calls the same method as the above method.
    public void TeamA_2points(View view){
        scoreTeamA+=2;
        displayForTeamA(scoreTeamA);
    }
    //free throw button click for team A, it calls the same method as above.
    public  void TeamA_freeThrow(View view){
        scoreTeamA+=1;
        displayForTeamA(scoreTeamA);
    }
    //score display function for Team A.
    private void displayForTeamA(int scoreA){
        TextView team_a = (TextView) findViewById(R.id.team_a_score);
        team_a.setText(""+scoreA);
    }
    //-----------------------------------------------------------------------------------

    // +3 points button click for team B, it calls the display function of Team B score.
    public void TeamB_3points(View view){
        scoreTeamB+=3;
        displayForTeamB(scoreTeamB);
    }
    // +2 points button click for team B, it also calls the same method as the above method.
    public void TeamB_2points(View view){
        scoreTeamB+=2;
        displayForTeamB(scoreTeamB);
    }
    //free throw button click for team A, it calls the same method as above.
    public void TeamB_freeThrow(View view){
        scoreTeamB+=1;
        displayForTeamB(scoreTeamB);
    }
    //score display function for Team B.
    private void displayForTeamB(int scoreB){
        TextView team_b = (TextView) findViewById(R.id.team_b_score);
        team_b.setText(""+scoreB);
    }
    // reset button to zero out both variables
    public void Reset(View view){
        scoreTeamA = 0;
        scoreTeamB = 0;
        displayForTeamA(scoreTeamA);
        displayForTeamB(scoreTeamB);
    }
}

